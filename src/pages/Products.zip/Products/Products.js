import React from "react";
import {
  MDBContainer,
  MDBRow,
  MDBCol,
  MDBCard,
  MDBCardBody,
  MDBCardImage,
  MDBIcon,
} from "mdb-react-ui-kit";
import 'bootstrap/dist/css/bootstrap.css';
import HeroSection from "./HeroSection";
import Brooke from "./Brooke & austin.jpeg";
import { Container } from "react-bootstrap";
import PhotographyContainer from "./PhotographyContainer";
import n1 from "./1.jpg";
import n2 from "./2.jpg";
import n3 from "./3.jpg";
import n4 from "./4.jpg";
import n5 from "./5.jpg";
import n6 from "./6.jpg";
import n7 from "./7.jpg";
import n8 from "./8.jpg";
import n9 from "./9.jpg";
import n10 from "./10.jpg";
import n11 from "./11.jpg";
import n12 from "./12.jpg";
import n13 from "./13.jpg";
import n14 from "./14.jpg";
import n15 from "./15.jpg";
import n16 from "./16.jpg";
import n17 from "./17.jpg";


export default function Products() {
  return (
    <>
    <HeroSection/>
    <MDBContainer fluid className="my-5">
      <Container style={{width:"100%"}}>
      <MDBRow style={{margin:"25px 0 0 0"}}>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={Brooke}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Brooke & Austin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                  Mistwood Golf Club
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n4}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Patrice & Ted</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                St. George’s
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n6}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Gabrielle & Nevin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                Ball Horticultural Gardens
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
      <MDBRow style={{margin:"25px 0 0 0"}}>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n7}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Brooke & Austin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                  Mistwood Golf Club
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n8}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Patrice & Ted</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                St. George’s
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n9}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Gabrielle & Nevin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                Ball Horticultural Gardens
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
      <MDBRow style={{margin:"25px 0 0 0"}}>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n15}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Brooke & Austin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                  Mistwood Golf Club
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n11}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Patrice & Ted</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                St. George’s
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
        <MDBCol md="12" lg="4" className="mb-4 mb-lg-0">
          <MDBCard>
            {/* <div className="d-flex justify-content-between p-3"></div> */}
            <MDBCardImage
              src={n13}
              position="top"
              alt="Laptop"
            />
            <MDBCardBody>
              <div className="d-flex justify-content-between">
                <p className="small"></p>
                <p className="small text-danger"></p>
              </div>

              <div className="d-flex justify-content-between mb-3">
                <h5 className="mb-0">Gabrielle & Nevin</h5>
                <h5 className="text-dark mb-0">$999</h5>
              </div>

              <div class="d-flex justify-content-between mb-2">
                <p class="text-muted mb-0">
                Ball Horticultural Gardens
                </p>
                <div class="ms-auto text-warning">
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                  <MDBIcon fas icon="star" />
                </div>
              </div>
            </MDBCardBody>
          </MDBCard>
        </MDBCol>
      </MDBRow>
      </Container>
    </MDBContainer>
    <PhotographyContainer/>
    </>
  );
}