import React from "react";
import p from "./p.jpg";

const HeroSection = () => {
  return (
    <div style={{ position: "relative", textAlign: "center", color: "white", margin: "0px" }}>
      {/* Background Image */}
      <img src={p} alt="Wedding Hall" style={{ width: "100%", height: "100vh", objectFit: "cover" }} />

      {/* Black Overlay */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          width: "100%",
          height: "100%",
          background: "rgba(0, 0, 0, 0.5)", // Adjust the opacity for darkness
        }}
      ></div>

      {/* Text Overlay */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          textAlign: "center",
          zIndex: 1, // Ensures text appears above the overlay
          width: "80%",
        }}
      >
        <h1 className="hero-title">We are storytellers at heart.</h1>
        <br></br><br></br>
        <h4 className="hero-description">
          Below is a collection of some of our wedding galleries. Each wedding tells a different story. 
          Explore real, beautiful moments and get in touch with us to schedule your consultation.
        </h4>
      </div>

      {/* Responsive Styles */}
      <style>
        {`
          .hero-title {
            font-size: 2.5rem;
          }
          .hero-description {
            font-size: 1.2rem;
            line-height: 1.6;
          }
          .hero-button {
            padding: 10px 20px;
            border-radius: 5px;
            border: none;
            background: white;
            color: black;
            font-size: 1rem;
          }

          @media (max-width: 768px) {
            .hero-title {
              font-size: 2rem; /* Smaller font for tablets */
            }
            .hero-description {
              font-size: 1rem; /* Reduce text size */
              line-height: 1.5;
            }
            .hero-button {
              font-size: 0.9rem;
              padding: 8px 16px;
            }
          }

          @media (max-width: 480px) {
            .hero-title {
              font-size: 1.9rem; /* Smaller font for mobile */
            }
            .hero-description {
              font-size: 1.3rem; /* Reduce text size */
              line-height: 1.5;
            }
            .hero-button {
              font-size: 0.8rem;
              padding: 6px 12px;
            }
          }
        `}
      </style>
    </div>
  );
};

export default HeroSection;
