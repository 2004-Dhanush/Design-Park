import React from "react";
import './index.css'
const PhotographyContainer = () => {
  return (
    <div
      className="bg-gray-200 text-gray-800 px-12 py-16  mx-auto rounded-lg shadow-lg "
      style={{ background: "#f0f0f0", width: "100%" }}
    >
      <h2 className="text-3xl font-extrabold text-gray-900 inline-block">
        DURON STUDIO PHOTOGRAPHY. BOUTIQUE STUDIO, CHICAGO & DESTINATION PHOTOGRAPHER
      </h2>
      <p className="mt-6 text-lg leading-relaxed text-gray-700">
      As soon as we open our photo albums, we get full of boundless enthusiasm to experience that special day once again. Is there anything more magical than reliving those moments? At Duron Studio Photography, we know for sure that photos are taken with the only aim – to make you deeply feel something good one more time. That is what our team of professional photographers in Chicago, IL strives to provide you with. Every shot is worth the smile on your face!
      </p>
      <p className="mt-6 text-lg leading-relaxed text-gray-700">
      Founded by Duron Shem-Tov, a distinguished Chicago  photographer, we are here to capture memorable moments that matter to you. Our photography and videography services have everything you need to have the opportunity to indulge yourself in the happiness of that special day again. Post-processing capabilities of our studio in combination with Duron’s artistic eye will help you feel natural in front of the camera and get gorgeous pictures to last you a lifetime.
      </p>

      <h3 className="text-2xl font-bold mt-8 text-gray-900">
        WHAT OCCASIONS DOES YOUR CHICAGO PHOTOGRAPHER SERVE?
      </h3>
      <p className="mt-4 text-lg leading-relaxed text-gray-700">
      As a full-functioning studio, based in the Chicagoland area with a love for travel, it’s hard for us to say no to any photo opportunity. Seizing those moments is what we’re all about. We have a love for all things fine art, but still maintain a lighthearted spirit in all that we do.
      </p>
      <p className="mt-4 text-lg leading-relaxed text-gray-700">
      Our goal is to make sure that your photos capture the gravity and the emotion of your special event. From stunning portraits, to incredible moments between you and your loved ones. We know the core foundations that not only make great photography, but also an incredible experience for you, your family, your friends, and all. Through expert posing, knowing all the key lighting tricks, and incredible storytelling, our goal is to make you look your best.
      </p>
      <p className="mt-4 text-lg leading-relaxed text-gray-700">
      Our client-first mentality and love for storytelling combined with our easygoing attitude comes through in all of our photos. At Duron Studio Photography, we are available for destination weddings and will beautifully shoot your ceremony even if it is held hundreds of miles away from Chicago.
      </p>
    </div>
  );
};

export default PhotographyContainer;
